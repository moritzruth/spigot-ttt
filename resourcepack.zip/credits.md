# Credits
## Sounds
Unless otherwise noted, the sound is from [bigsoundbank.com](https://bigsoundbank.com)

- ["Firearm Reloading 2"](https://freesound.org/people/davdud101/sounds/150500/)
by [davdud101](https://freesound.org/people/davdud101/)
is licensed under [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)

- ["beep.wav"](https://freesound.org/people/downwiththemachines/sounds/165369/)
by [downwiththemachines](https://freesound.org/people/downwiththemachines/)
is licensed under [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/)

- ["Scream 1"](https://freesound.org/people/TheSubber13/sounds/239900/)
by [TheSubber13](https://freesound.org/people/TheSubber13/)
is licensed under [CC BY-NC 3.0](https://creativecommons.org/licenses/by-nc/3.0/)
